package com.example.covid.covid;

import com.example.covid.covid.Model.User;
import com.example.covid.covid.Repository.UserRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(value = true)
public class UserRepositoryTest {
    @Autowired
    private UserRepository userRepository;

    @Test
    public void testAddNewUser() {
        User user = new User();
        user.setEmail("juxhingjata12@gmail.com");
        user.setFirstName("juxhin");
        user.setLastName("gjata");
        user.setPassword("regular123");
        user.setUserType("regular");

        User savedUser = userRepository.save(user);

        Assertions.assertNotEquals(savedUser, null);
        Assertions.assertNotEquals(savedUser.getId(), 0);
    }


}
