package com.example.covid.covid.Service;

import com.example.covid.covid.Repository.UserRepository;
import com.example.covid.covid.Model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.rmi.ServerException;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public List<User> listAll() {
        return (List<User>) userRepository.findAll();
    }
    public void addUser(User user) {
        userRepository.save(user);
    }
    public User get(Integer id) throws ServerException {
        Optional<User> user = userRepository.findById(id);
        if(user.isPresent())
            return user.get();
        throw new ServerException("User Not Found!");
    }

    public boolean authenticate(String email, String password) {
        Optional<User> user = Optional.ofNullable(userRepository.findUserByEmailAndPassword(email, password));
        System.out.println(user);
        if (user.isPresent())
            return true;
        return false;
    }
    public User findByEmail(String email) throws ServerException {
        Optional<User> user = Optional.ofNullable(userRepository.findUserByEmail(email));
        if(user.isPresent())
            return user.get();
        throw new ServerException("User Not Found!");
    }
    public User findById(Integer id) throws ServerException {
        Optional<User> user = userRepository.findById(id);
        if(user.isPresent())
            return user.get();
        throw new ServerException("User Not Found!");
    }
    public void deleteUser(User user) {
        userRepository.delete(user);
    }
}
