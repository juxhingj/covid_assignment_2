package com.example.covid.covid.Model;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "covidData")
@Data
@AllArgsConstructor @NoArgsConstructor
public class CovidData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Setter(AccessLevel.NONE)
    private Integer id;

    private String COD, CNT, LOC;
    private double TC, TD, TT;
    private double SI, POP, MA;
}
