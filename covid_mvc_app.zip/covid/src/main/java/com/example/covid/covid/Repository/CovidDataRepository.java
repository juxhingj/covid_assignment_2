package com.example.covid.covid.Repository;

import com.example.covid.covid.Model.CovidData;
import org.springframework.data.repository.CrudRepository;

public interface CovidDataRepository extends CrudRepository<CovidData, Integer> {
    CovidData findCovidDataByCOD(String cod);
}
