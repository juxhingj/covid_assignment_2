package com.example.covid.covid.Repository;

import com.example.covid.covid.Model.User;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserRepository extends CrudRepository<User, Integer> {

    User findUserByEmailAndPassword(String email, String password);
    User findUserByEmail(String email);
}
