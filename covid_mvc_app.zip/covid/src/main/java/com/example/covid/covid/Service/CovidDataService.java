package com.example.covid.covid.Service;

import com.example.covid.covid.Model.CovidData;
import com.example.covid.covid.Repository.CovidDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class CovidDataService {
    @Autowired
    private CovidDataRepository covidDataRepository;

    public void addData(CovidData covidData) {
        covidDataRepository.save(covidData);
    }
    public void deleteAll() {
        covidDataRepository.deleteAll();
    }
    public ArrayList<CovidData> listAll() {
        return (ArrayList<CovidData>) covidDataRepository.findAll();
    }
    public CovidData findByCod(String cod) {
        return covidDataRepository.findCovidDataByCOD(cod);
    }
}
