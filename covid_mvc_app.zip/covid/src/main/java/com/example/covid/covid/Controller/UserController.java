package com.example.covid.covid.Controller;

import com.example.covid.covid.Model.CovidData;
import com.example.covid.covid.Model.Row;
import com.example.covid.covid.Model.User;
import com.example.covid.covid.Service.CovidDataService;
import com.example.covid.covid.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.rmi.ServerException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

@Controller
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private CovidDataService covidDataService;

    @GetMapping("/users")
    public String showUserList(WebRequest req, Model model) throws ServerException {
        String email = req.getParameter("email");
        User user = null;
        if (email.length() > 0)
            user = userService.findByEmail(email);
        List<User> userList = userService.listAll();
        model.addAttribute("userList", userList);
        if (user != null) model.addAttribute("user", user);
        if (user != null) model.addAttribute("userName", user.getFirstName()+ " " + user.getLastName());
        return "users";
    }

    public ArrayList<CovidData> getData(ArrayList<String> countries, boolean all) {
        if(all)
            return covidDataService.listAll();
        ArrayList<CovidData> res = new ArrayList<>();
        if (countries == null)
            return res;
        for(String country : countries) {
            res.add(covidDataService.findByCod(country));
        }
        return res;

    }

    @GetMapping("/guest")
    public String guest(Model model) {
        model.addAttribute("pageTitle", "Welcome");
        model.addAttribute("userName", "Guest");
        model.addAttribute("data",getData(null, true));
        return "guest";
    }

    @GetMapping("/main")
    public String main(@RequestParam String email, Model model) throws ServerException {

        User user = userService.findByEmail(email);
        model.addAttribute("user",user);
        model.addAttribute("pageTitle", "Welcome");
        model.addAttribute("userName", user.getFirstName() + " " + user.getLastName());
        model.addAttribute("data",getData(user.getCountries(), false));
        return "main";
    }



    @PostMapping("/authenticate")
    public String authenticate(WebRequest req, RedirectAttributes ra, Model model) throws ServerException {
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        boolean auth = userService.authenticate(email, password);

        if(auth == true) {
            User user = userService.findByEmail(email);
            if (user.getUserType().equals("admin"))
                return "redirect:/users?email=" + email;
            return "redirect:/main?email="+email;
        }
        else {
            ra.addFlashAttribute("message","Email or Password is incorrect!");
            return "redirect:/";
        }


    }
    @PostMapping("/user")
    public String addUser(User user, RedirectAttributes ra, WebRequest req) {
        System.out.println(user);
        String[] em = user.getEmail().split(",");
        user.setEmail(em[1]);
        userService.addUser(user);
        ra.addFlashAttribute("message","User Saved Successfully!");
        return "redirect:/users?email="+req.getParameter("email");
    }
    @GetMapping("/editUser")
    public String editUser(WebRequest req, Model model) throws ServerException {
        String email = req.getParameter("email");
        User user = userService.findByEmail(email);
        model.addAttribute("pageTitle", "Edit User: " + user.getEmail() );
        model.addAttribute("user", user);
        return "editUserForm";
    }
    @PostMapping("/edit")
    public String edit(User user, String email, RedirectAttributes ra) throws ServerException {
        User curUser = userService.findByEmail(email);
        user.setId(curUser.getId());
        user.setCountries(curUser.getCountries());
        userService.addUser(user);
        ra.addFlashAttribute("updateMessage","User Updated Successfully!");
        if (user.getUserType().equals("admin"))
            return "redirect:/users?email="+email;
        return "redirect:/main?email=" + email;
    }

    @PostMapping("/addCountry")
    public String addCountry(WebRequest req, RedirectAttributes ra) throws ServerException {
        String email = req.getParameter("email");
        String code = req.getParameter("country").toUpperCase(Locale.ROOT);
        User user = userService.findByEmail(email);
        ArrayList<String> cur;
        if (user == null)
            cur = null;
        else
            cur = user.getCountries();
        if(cur == null)
            cur = new ArrayList<>();
        CovidData covidData = covidDataService.findByCod(code);
        if (covidData != null)
        {
            System.out.println(cur);
            if (!cur.contains(code)) {
                cur.add(code);
                user.setCountries(cur);
                userService.addUser(user);
                ra.addFlashAttribute("message", "Successfully Added: " + code);

            }
            else
                ra.addFlashAttribute("message", "Already Exists: " + code);

        }
        else {
            ra.addFlashAttribute("message", "Invalid Code: " + code);
        }
        return "redirect:/main?email="+email;

    }

    @GetMapping("/removeCountry")
    public String removeCountry(WebRequest req, RedirectAttributes ra) throws ServerException {
        String email = req.getParameter("email");
        String code = req.getParameter("country").toUpperCase(Locale.ROOT);
        User user = userService.findByEmail(email);
        ArrayList<String> cur;
        if (user == null)
            cur = null;
        else
            cur = user.getCountries();

        if (cur != null)
        {
            cur.remove(code);
            if(user != null) {
                user.setCountries(cur);
                userService.addUser(user);
            }
            ra.addFlashAttribute("message", "Successfully Removed: " + code);
        }
        else {
            ra.addFlashAttribute("message", "Failed To Remove: " + code);
        }
        return "redirect:/main?email="+email;

    }


    @GetMapping("/users/delete/{id}")
    public String deleteUser(@PathVariable Integer id, WebRequest req, RedirectAttributes ra) throws ServerException {
        String email = req.getParameter("email");
        User user = userService.findById(id);
        userService.deleteUser(user);
        ra.addFlashAttribute("updateMessage","User Deleted Successfully: " + user.getEmail());
        return "redirect:/users?email="+email;
    }

    @GetMapping("/users/new")
    public String showNewUserForm(Model model, RedirectAttributes ra, WebRequest req) {
        model.addAttribute("user", new User());
        model.addAttribute("pageTitle", "Add New User");
        model.addAttribute("adminEmail",req.getParameter("email"));
        return "newUserForm";

    }


    // Function which splits given String into tokens based on the delimiter
    public static String[] mySplit(String st, Character delim) {
        ArrayList<String> ret = new ArrayList<>();
        int i = 0;
        String temp = "";
        while (i < st.length()) {
            temp= "";
            if (st.charAt(i) != delim) {
                while (i<st.length() && st.charAt(i) != delim) {
                    temp += st.charAt(i);
                    i += 1;
                }
                ret.add(temp);
            }
            else {
                ret.add(temp);
            }
            i+=1;
        }
        ret.add(temp);
        String a[] = new String[ret.size()];
        for(i=0; i < ret.size(); i++)
            a[i] = ret.get(i);
        return a;
    }

    @GetMapping("/populate")
    public String populateData() throws IOException {
        covidDataService.deleteAll();
        ArrayList<Row> rows = new ArrayList<>();
        HashMap<String, String> countries = new HashMap<>();
        // stream the dataset
        File file = new ClassPathResource("owid-covid-data.csv").getFile();
        Files.lines(file.toPath())
                .map(line -> mySplit(line, ','))
                .skip(1)
                .forEach(a -> rows.add(new Row(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7],
                        a[8], a[9], a[16], a[25], a[26], a[47], a[48], a[50])));
        // now cumulate all the rows based on countries as keys
        for(Row r : rows) countries.put(r.getCOD(),r.getLOC());
        // countries.forEach((c,name)-> System.out.println(c + ":" + name));
        HashMap<String, Row> finalData = new HashMap<>();
        countries.forEach((code,name)->{
            finalData.put(code, new Row());
            finalData.get(code).setCOD(code);
            finalData.get(code).setLOC(name);

            finalData.get(code).setTC(0.0);
            finalData.get(code).setTD(0.0);
            finalData.get(code).setTT(0.0);
        });
        rows.forEach((row)->{
            double prevTT = finalData.get(row.getCOD()).getTT();
            finalData.get(row.getCOD()).setTT(prevTT + row.getTT());

            double prevTD = finalData.get(row.getCOD()).getTD();
            finalData.get(row.getCOD()).setTD(prevTD + row.getTD());

            double prevTC = finalData.get(row.getCOD()).getTC();
            finalData.get(row.getCOD()).setTC(prevTC + row.getTC());

            finalData.get(row.getCOD()).setCNT(row.getCNT());
            finalData.get(row.getCOD()).setPOP(row.getPOP());
            finalData.get(row.getCOD()).setMA(row.getMA());
            finalData.get(row.getCOD()).setSI(row.getSI());

        });

        // save these rows
        finalData.forEach((code, row) -> {
            CovidData covidData = new CovidData();
            covidData.setCNT(row.getCNT());
            covidData.setCOD(row.getCOD());
            covidData.setLOC(row.getLOC());
            covidData.setPOP(row.getPOP());
            covidData.setMA(row.getMA());
            covidData.setSI(row.getSI());
            covidData.setTC(row.getTC());
            covidData.setTD(row.getTD());
            covidData.setTT(row.getTT());
            covidDataService.addData(covidData);
        });
        return "index";
    }
}
