package com.example.covid.covid.Model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) @Getter @Setter
    private Integer id;

    @Column(nullable = false, length = 45)
    @Getter @Setter
    private String firstName;

    @Column(nullable = false, length = 45)
    @Getter @Setter
    private String lastName;

    @Column(nullable = false, length = 45)
    @Getter @Setter
    private String email;

    @Column(nullable = false, unique = true, length = 45)
    @Getter @Setter
    private String password;

    @Column(nullable = false, length = 45)
    @Getter @Setter
    private String userType;

    @Getter @Setter
    private ArrayList<String> countries;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", password='" + password + '\'' +
                ", userType='" + userType + '\'' +
                ", countries=" + countries +
                '}';
    }
}
